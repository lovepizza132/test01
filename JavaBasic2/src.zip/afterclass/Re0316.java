package afterclass;

import java.util.*;

public class Re0316 {

	public static void main(String[] args) {
		// 윤달 계산 4년에 한번, 100년마다는 제외  400년마다는 윤달.
		
		int year = 0;
		
		Scanner input = new Scanner(System.in);
		System.out.println("윤달판별기 - 년도를 입력해주세요");
		year = input.nextInt();
		
		if( (year % 4 == 0 && year % 100 != 0) || year % 400 == 0 ) {
			System.out.println("윤달입니다.");
		}else {
			System.out.println("윤달이 아닙니다.");
		}
	}
}