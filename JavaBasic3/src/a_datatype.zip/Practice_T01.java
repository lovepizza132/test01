package a_datatype;

public class Practice_T01 {

	public static void main(String[] args) {


//	// 1번 문제
//		byte b = -128; // byte의 범위는 -128~127
//
//	//2번 문제	
//		int i = 12345678;
//		float f = 3.5;
//		double d = 12345678.0;
//		String s = "";	
//		
//	//3번 문제
//		byte a = 64;
//		byte b = 64;
//		byte result = a + b;
//		System.out.println("result= " + result);
//	
//	//4번 문제
//		byte b = 36;
//		int i = (int)b;
//		System.out.println("b = "+ b);
//		System.out.println("i = "+ i);
		
	//5번 문제	
		/*
		int i = 360;
		byte b = (byte)i;
		System.out.println("i= " +i);
		System.out.println("b= " +b);
	*/
		
	//6번 문제
		 byte  b = 127;

         char  ch = '글';

         int    i = 20000000;

     long  l =  1L;
		
     b = ( byte ) i;

     i = ( int ) ch;

     int  var = ( int ) b;

     float  f = (float) l;

     l = (long)i;
     
     System.out.println(l);
     System.out.println(b);
     System.out.println(i);
     System.out.println(var);
     System.out.println(f);
     
		
		
	}

}
