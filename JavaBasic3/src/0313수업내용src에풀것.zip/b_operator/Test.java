package b_operator;

public class Test {

	public static void main(String[] args) {
		// 연습문제풀이
		
		// 1번 문제 
		int i = 4, j = 2;
		i = i << 2;
		System.out.println("result: " + i); // 16
		
		// 3번 문제
		System.out.println( 4 && 7 ); //1
		
		// 4번 문제
		int i = 5
		System.out.println( i++ );//5
		System.out.println( i++ );//6
		
		// 5번 문제
		int a = -5
		if( (a > 0) ) && ( ( (++a/3) > 0 ) ){
			a++;
		}
		System.out.println(a);// -5
	}

}
