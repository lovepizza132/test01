 package b_operator;

public class Ex08_ShortCircuitLogic {

	public static void main(String[] args) {
		

		
	}

}
