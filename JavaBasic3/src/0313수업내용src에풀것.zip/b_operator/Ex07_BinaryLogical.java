package b_operator;

/*
 * 	이진논리 : &(and) |(or) ^(xor)
 */
public class Ex07_BinaryLogical {

	public static void main(String[] args) {
		int a = 15;
		int b = 10;
		
		System.out.println( a & b ); //10
		System.out.println( a | b ); //15
		System.out.println( a ^ b ); //5

	}

}
