package b_operator;

public class Ex11 {

	public static void main(String[] args) {
		
		int  z = 10 - 7 ^ 3 + 1 * 2 & 4;
		// z 값은?
		System.out.println(z);

	}

}
