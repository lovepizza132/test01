package b_operator;

public class Ex07_BinaryLogical {

	public static void main(String[] args) {
		


	}

}
